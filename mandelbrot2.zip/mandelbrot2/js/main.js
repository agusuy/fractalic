
var canvas = new Canvas(w,h,canvasId);

for(x=0;x<w;x++){
	for(y=0;y<h;y++){

		var result = mandelbrotSet(x, y, maxIterations);

		var iteration = result.iteration;
		var z_re = result.z_re;
		var z_im = result.z_im;

		var color = coloring(iteration, maxIterations, z_re, z_im);

		canvas.putPixel(color[0],color[1],color[2], x,y);
	}
}

canvas.render();